#include "subject.h"

Subject::Subject()
{

}

Subject::~Subject()
{

}
