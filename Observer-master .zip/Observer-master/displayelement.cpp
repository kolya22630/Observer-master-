#include "displayelement.h"

DisplayElement::DisplayElement()
{

}

DisplayElement::~DisplayElement()
{

}
